public class Person {
    private String name;
    private String surname;
    private String email;

    public Person(String name, String surename, String email){
        this.name= name;
        this.surname= surename;
        this.email=email;


    }
public String getName(){
    return name;
}

public String getSurname(){
        return surname;
 }

 public String getEmail(){
        return email;
 }
 public void setName(){
        this.name=name;
 }
public void setSurname(){
        this.surname=surname ;
}
public void setEmail(){
        this.email=email;
}
public void person_info(){
    System.out.println("Name= " +getName());
    System.out.println("Surename= "+getSurname());
    System.out.println("Email= "+getEmail());
}
}
