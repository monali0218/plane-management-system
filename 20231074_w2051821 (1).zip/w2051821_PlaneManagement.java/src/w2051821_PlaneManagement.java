import java.util.*;

public class w2051821_PlaneManagement {
    public static int ticketprice;
    public static int ticket_count=1;
    public static int[][] seat_array = {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
    public static Ticket[] ticket_array= new Ticket[52];

    public static void main(String[] args) {
        boolean run = true;
        Scanner optionScanner = new Scanner(System.in);

        do {
            displayMenu();
            System.out.println("Please select an option (0-6): ");

            try {
                int menu_option = optionScanner.nextInt();

//                if (menu_option < 0 || menu_option > 6) {
//                    System.out.println("Invalid input. Please enter a number between 0 and 6.");
//                    continue; // Skip the rest of the loop and prompt again
//                }

                switch (menu_option) {
                    case 1:
                        buy_seat();
                        break;
                    case 2:
                        cancel_seat();
                        break;
                    case 3:
                        find_first_available();
                        break;
                    case 4:
                        show_seating_plan();
                        break;
                    case 5:
                        print_tickets_info();
                        break;
                    case 6:
                        search_ticket();
                        break;
                    case 0:
                        run = false;
                        break;
                    default:
                        System.out.println("Invalid input. Please enter a number between 0 and 6.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input!!");
                optionScanner.next(); // Clear the invalid input
            }
        } while (run);
    }
    private static void displayMenu() {
        // Display the welcome message and menu options
        System.out.println(" Welcome to the Plane Management application \n ************************** \n *       MENU OPTIONS     * \n **************************");

        // Display menu options
        System.out.println(" 1) Buy a seat"); // Option for buying a seat
        System.out.println(" 2) Cancel a seat"); // Option for canceling a seat
        System.out.println(" 3) Find first available seat"); // Option for finding the first available seat
        System.out.println(" 4) Show seating plan"); // Option for showing the seating plan
        System.out.println(" 5) Print tickets information and total sales"); // Option for printing tickets information and total sales
        System.out.println(" 6) Search ticket"); // Option for searching a ticket
        System.out.println(" 0) Quit"); // Option for quitting the application
    }

    // This method allows the user to buy a seat
    static void buy_seat() {
        String name;
        String surname;
        String email;

        // Prompt the user to enter the row letter of the seat
        System.out.println("Enter the row letter of the seat: ");

        // Read the row letter input from the user
        Scanner option = new Scanner(System.in);
        char row = option.next().toUpperCase().charAt(0);

        try { int seat;
            // Check if the entered row is within valid range (A-D)
            if (row >= 'A' && row <= 'D') {
                try {
                    System.out.println("Enter the seat number.");
                    seat = option.nextInt();
                } catch (InputMismatchException e){
                    System.out.println("enter a integer.");
                    return;
                }

                // Check if the entered row number is within valid range (1-14)
                if (seat <= 14 && seat >= 1) {
                    switch (row) {
                        // Check availability of the seat in the specified row
                        case 'A':
                            if (seat_array[0][seat - 1] == 0) {
                                seat_array[0][seat - 1] = 1;

                                System.out.println();
                            } else {
                                System.out.println("Seat is not available. Please choose a different seat.");
                            }
                            break;
                        case 'B':
                            if (seat_array[1][seat - 1] == 0) {
                                seat_array[1][seat - 1] = 1;

                                System.out.println();
                            } else {
                                System.out.println("Seat is not available. Please choose a different seat.");
                            }
                            break;
                        case 'C':
                            if (seat_array[2][seat - 1] == 0) {
                                seat_array[2][seat - 1] = 1;

                                System.out.println();
                            } else {
                                System.out.println("Seat is not available. Please choose a different seat.");
                            }
                            break;
                        case 'D':
                            if (seat_array[3][seat - 1] == 0) {
                                seat_array[3][seat - 1] = 1;

                                System.out.println();
                            } else {
                                System.out.println("Seat is not available. Please choose a different seat.");
                            }
                            break;
                        default:
                            System.out.println("Invalid inputs!! Enter a letter from A-D.");
                            break;
                    }
                    // Prompt the user to enter person details

                    while (true) {
                        System.out.print("Enter your name:");
                        name = option.next();
                        if (name.matches("[a-zA-Z]+")){
                            break;
                        }else {
                            System.out.println("Invalid name. Name cannot contain numbers or special characters");
                        }
                    }

                    while (true) {
                        System.out.print("Enter your surname:");
                        surname = option.next();
                        if (surname.matches("[a-zA-Z]+")){
                            break;
                        }else {
                            System.out.println("Invalid name. Surname cannot contain numbers or special characters");
                        }
                    }

                    while (true) {
                        System.out.print("Enter your email:");
                        email = option.next();
                        if (email.contains("@") && email.contains(".")){
                            break;

                        }else {
                            System.out.println("Invalid email. Please enter a valid email address.");
                        }
                    }
                    System.out.println("\n  Your ticket has been Booked");

                    // Create a new Person object with entered details
                    Person personal_details= new Person(name,surname,email);

                    // Generate ticket information and create a new Ticket object
//                    ticket_information();

                    if ( seat >= 1 && seat <= 5) {
                        ticketprice = 200;
                    } else if ( seat >= 6 && seat <= 9) {
                        ticketprice = 150;
                    }
                    else {
                        ticketprice = 180;
                    }

                    Ticket ticket_details=new Ticket(row,seat,ticketprice,personal_details);

                    // Save ticket details to a file
                    ticket_details.save();

                    // Store ticket details in the ticket_array and increment ticket_count
                    ticket_array[ticket_count]=ticket_details;
                    ticket_count++;
                } else {
                    System.out.println("Enter the correct range");
                }
            } else {
                System.out.println("Enter the correct value.");
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Enter the correct range");
        }
    }


    static void cancel_seat() {
        // Prompt the user to enter the row letter of the seat
        System.out.println("Enter the row letter of the seat");
        Scanner option = new Scanner(System.in);
        char row = option.next().toUpperCase().charAt(0);

        // Check if the entered row letter is valid (A to D)
        if (row >= 'A' && row <= 'D') {
            int seat;
            // Prompt the user to enter the row number of the seat
            try {
                System.out.println("Enter the seat number.");
                seat = option.nextInt();
            } catch (InputMismatchException e){
                System.out.println("enter a integer.");
                return;
            }

            // Check if the entered row number is within the valid range (1 to 14)
            if (seat <= 14 && seat >= 1) {
                // Switch statement to handle different rows
                switch (row) {
                    case 'A':
                        if (seat_array[0][seat - 1] == 1) {
                            seat_array[0][seat - 1] = 0;
                            System.out.println("Cancelled");
                            System.out.println();
                        } else {
                            System.out.println("Your seat has already been cancelled or does not exist.");
                        }
                        break;
                    case 'B':
                        if (seat_array[1][seat - 1] == 1) {
                            seat_array[1][seat - 1] = 0;
                            System.out.println("Cancelled");
                            System.out.println();
                        } else {
                            System.out.println("Your seat has already been cancelled or does not exist.");
                        }
                        break;
                    case 'C':
                        if (seat_array[2][seat - 1] == 1) {
                            seat_array[2][seat - 1] = 0;
                            System.out.println("Cancelled");
                            System.out.println();
                        } else {
                            System.out.println("Your seat has already been cancelled or does not exist.");
                        }
                        break;
                    case 'D':
                        if (seat_array[3][seat - 1] == 1) {
                            seat_array[3][seat - 1] = 0;
                            System.out.println("Cancelled");
                        } else {
                            System.out.println("Your seat has already been cancelled or does not exist.");
                        }
                        break;
                }

                // Loop through the ticket array to find and delete the corresponding ticket
                for (int cancel_seat = 0; cancel_seat < ticket_count; cancel_seat++) {
                    if (ticket_array[cancel_seat] != null){
                        if (ticket_array[cancel_seat].getRow() == row && ticket_array[cancel_seat].getSeat() == seat){
                            ticket_array[cancel_seat].delete(); // Delete the ticket associated with the cancelled seat
                            ticket_array[cancel_seat] = null;
                        }
                    }
                }
            } else {
                System.out.println("Enter the row number within the correct range (1 to 14).");
            }
        } else {
            System.out.println("Enter the correct row letter (A to D).");
        }
    }

    static void find_first_available() {
        for (int i = 0; i < seat_array.length; i++) {
            for (int j = 0; j < seat_array[i].length; j++) {
                if (seat_array[i][j] == 0) {

                    if (i == 0) {
                        System.out.println("The first seat available is in row A" + (j+1));
                        return;
                    } else if (i == 1) {
                        System.out.println("The first seat available is in row B" + (j+1));
                        return;
                    } else if (i == 2) {
                        System.out.println("The first seat available is in row C" + (j+1));
                        return;
                    } else {
                        System.out.println("The first seat available is in row D" + (j+1));
                        return;
                    }
                }
            }
        }
    }

    static void show_seating_plan() {
        System.out.println("     - Seating Plan -   ");
        for (int i = 0; i < seat_array.length; i++) {
            for (int j = 0; j < seat_array[i].length; j++) {
                // Check if the seat is booked (1) or available (0)
                if (seat_array[i][j] == 1) {
                    System.out.print("X "); // Booked seat
                } else {
                    System.out.print("O "); // Available seat
                }
            }
            System.out.println(""); // Move to the next row
        }
    }

    public static void print_tickets_info() {
        double b = 0;
        for (int a = 1; a < ticket_count; a++) {
            if (ticket_array[a] != null) { // Check if individual element is initialized
                ticket_array[a].ticket_info();
                b += ticket_array[a].getPrice();
            }
        }
        System.out.println("Total: "+b);
    }

    public static void search_ticket() {
        int seat;
        Scanner opt = new Scanner(System.in);

        System.out.println("enter the row letter of the seat");
        char RowLetter = opt.next().toUpperCase().charAt(0);
        try {
            System.out.println("Enter the seat number.");
            seat = opt.nextInt();
        } catch (InputMismatchException e){
            System.out.println("enter an integer.");
            return;

        }
        boolean flag = false;
        for (int a = 0; a < ticket_count; a++){
            if ( ticket_array[a] != null ){
                if ( ticket_array[a].getRow() == RowLetter && ticket_array[a].getSeat() == seat) {
                    ticket_array[a].ticket_info();
                    flag=true;
                    break;

                }
                else {
                    System.out.println("This seat is available ");
                    flag=true;
                    break;

                }
            }
            }
        if (!flag){
            System.out.println("There is no info");
        }
        }
    }
